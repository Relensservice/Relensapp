const express = require('express');
const config = require('./config');
const business = require('./businessConfig');
const { sendWhatsAppMessage } = require('./services/whatsapp');
const { sendInstagramMessage } = require('./services/instagram');
const { handleMessage } = require('./services/openai');
const { createPaymentLink } = require('./services/razorpay');
const { notifyTeam } = require('./services/notify');

const app = express();
app.use(express.json());

// --- Webhook verification: Meta calls this once when you subscribe ---
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === config.whatsapp.verifyToken) {
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

// --- Incoming messages: WhatsApp and Instagram both post here ---
app.post('/webhook', async (req, res) => {
  res.sendStatus(200); // Meta requires a fast ack — do the work after

  const body = req.body;
  try {
    if (body.object === 'whatsapp_business_account') {
      await handleWhatsAppEvent(body);
    } else if (body.object === 'instagram') {
      await handleInstagramEvent(body);
    }
  } catch (err) {
    console.error('Webhook processing error:', err);
  }
});

async function handleWhatsAppEvent(body) {
  const message = body.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
  if (!message || message.type !== 'text') return;

  const fromPhone = message.from;
  const text = message.text.body;
  const { intent, reply } = await handleMessage(text);

  await routeIntent(intent, reply, text, {
    replyFn: (msg) => sendWhatsAppMessage(fromPhone, msg),
    customerHandle: fromPhone,
  });
}

async function handleInstagramEvent(body) {
  const messaging = body.entry?.[0]?.messaging?.[0];
  const text = messaging?.message?.text;
  const senderId = messaging?.sender?.id;
  if (!text || !senderId) return;

  const { intent, reply } = await handleMessage(text);

  await routeIntent(intent, reply, text, {
    replyFn: (msg) => sendInstagramMessage(senderId, msg),
    customerHandle: senderId,
  });
}

// --- Shared routing logic for both channels ---
async function routeIntent(intent, aiReply, originalText, { replyFn, customerHandle }) {
  switch (intent) {
    case 'booking':
      await replyFn(`${aiReply}\n\nBook directly here: ${business.bookingLink}`);
      break;

    case 'payment': {
      // Placeholder amount — in production, have the AI extract the specific
      // service + price first, or ask a follow-up question before charging.
      const link = await createPaymentLink(499, `${business.businessName} payment`, customerHandle);
      await replyFn(`${aiReply}\n\nPay here: ${link}`);
      break;
    }

    case 'escalate':
      await replyFn(aiReply);
      await notifyTeam(`Customer ${customerHandle} needs a human reply: "${originalText}"`);
      break;

    case 'faq':
    default:
      await replyFn(aiReply);
  }
}

app.listen(config.port, () => {
  console.log(`${business.businessName} AI front desk running on port ${config.port}`);
});
