const axios = require('axios');
const config = require('../config');

const GRAPH_API_VERSION = 'v21.0';

async function sendWhatsAppMessage(toPhone, text) {
  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${config.whatsapp.phoneNumberId}/messages`;

  try {
    await axios.post(
      url,
      {
        messaging_product: 'whatsapp',
        to: toPhone,
        type: 'text',
        text: { body: text },
      },
      {
        headers: {
          Authorization: `Bearer ${config.whatsapp.accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (err) {
    console.error('WhatsApp send failed:', err.response?.data || err.message);
  }
}

module.exports = { sendWhatsAppMessage };
