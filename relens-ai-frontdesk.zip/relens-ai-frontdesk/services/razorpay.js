const Razorpay = require('razorpay');
const config = require('../config');

const instance = new Razorpay({
  key_id: config.razorpay.keyId,
  key_secret: config.razorpay.keySecret,
});

async function createPaymentLink(amountInRupees, description, customerPhone) {
  const link = await instance.paymentLink.create({
    amount: amountInRupees * 100, // Razorpay expects paise
    currency: 'INR',
    description,
    customer: { contact: customerPhone },
    notify: { sms: true, whatsapp: true },
  });
  return link.short_url;
}

module.exports = { createPaymentLink };
