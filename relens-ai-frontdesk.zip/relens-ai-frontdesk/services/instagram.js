const axios = require('axios');
const config = require('../config');

const GRAPH_API_VERSION = 'v21.0';

async function sendInstagramMessage(recipientId, text) {
  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${config.instagram.pageId}/messages`;

  try {
    await axios.post(
      url,
      {
        recipient: { id: recipientId },
        message: { text },
      },
      {
        headers: {
          Authorization: `Bearer ${config.instagram.accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (err) {
    console.error('Instagram send failed:', err.response?.data || err.message);
  }
}

module.exports = { sendInstagramMessage };
