const { sendWhatsAppMessage } = require('./whatsapp');
const config = require('../config');

async function notifyTeam(message) {
  const recipients = [config.team.ownerPhone, config.team.managerPhone].filter(
    Boolean
  );
  await Promise.all(
    recipients.map((phone) => sendWhatsAppMessage(phone, `🔔 ${message}`))
  );
}

module.exports = { notifyTeam };
