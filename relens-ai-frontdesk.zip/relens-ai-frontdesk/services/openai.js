const OpenAI = require('openai');
const config = require('../config');
const business = require('../businessConfig');

const client = new OpenAI({ apiKey: config.openai.apiKey });

function buildSystemPrompt() {
  const serviceList = business.services
    .map((s) => `${s.name} — ${s.price}`)
    .join(', ');

  return `You are the front-desk assistant for ${business.businessName}.
Only answer using the business info below — never invent prices, hours,
or services that aren't listed here.

BUSINESS INFO:
${business.aboutText}
Hours: ${business.hours}
Booking link: ${business.bookingLink}
Services: ${serviceList}

Classify every customer message into exactly one intent, then write a reply.
Respond ONLY as JSON in this shape:
{"intent": "faq" | "booking" | "payment" | "escalate", "reply": "..."}

Intent guide:
- "faq": general questions answerable from the business info above
- "booking": the customer wants to book or schedule an appointment
- "payment": the customer wants to pay, or asks for a payment link
- "escalate": complaints, anything uncertain, or questions outside the info above

Keep replies short and warm. Reply in the same language the customer used.`;
}

async function handleMessage(customerText) {
  const completion = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: buildSystemPrompt() },
      { role: 'user', content: customerText },
    ],
    response_format: { type: 'json_object' },
  });

  try {
    return JSON.parse(completion.choices[0].message.content);
  } catch (err) {
    return { intent: 'escalate', reply: "Let me connect you with our team." };
  }
}

module.exports = { handleMessage };
