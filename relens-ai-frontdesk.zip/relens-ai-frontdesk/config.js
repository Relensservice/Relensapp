require('dotenv').config();

module.exports = {
  whatsapp: {
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID,
    accessToken: process.env.WHATSAPP_ACCESS_TOKEN,
    verifyToken: process.env.WHATSAPP_VERIFY_TOKEN,
  },
  instagram: {
    pageId: process.env.INSTAGRAM_PAGE_ID,
    accessToken: process.env.INSTAGRAM_ACCESS_TOKEN,
  },
  team: {
    ownerPhone: process.env.OWNER_PHONE,
    managerPhone: process.env.MANAGER_PHONE,
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
  },
  razorpay: {
    keyId: process.env.RAZORPAY_KEY_ID,
    keySecret: process.env.RAZORPAY_KEY_SECRET,
  },
  port: process.env.PORT || 3000,
};
