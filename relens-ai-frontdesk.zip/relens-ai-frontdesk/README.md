# Relens AI Front Desk

An AI-powered "front office employee" that answers WhatsApp and Instagram
messages automatically — handles FAQs, points customers to your Setmore
booking page, sends Razorpay payment links, and pings you or your manager
by WhatsApp whenever a real human needs to step in.

## Where this fits your plan

This is a **direct-to-Meta build** — it talks to WhatsApp/Instagram through
Meta's own Cloud API, not through a paid BSP dashboard like Cleomitra or
AiSensy. That's a real trade-off, worth knowing before you commit:

|  | This custom bot | A BSP tool (Cleomitra/AiSensy/etc.) |
|---|---|---|
| Monthly platform fee | ₹0 (you only pay OpenAI usage + hosting, a few hundred ₹/month) | ₹999–3,500+/month |
| Setup | You (or a developer) maintain code | Point-and-click dashboard, no code |
| Flexibility | Fully custom logic, yours to extend | Limited to what the tool offers |
| Support | You're on your own / Meta docs | Vendor support included |

You don't have to pick one forever — many people prototype with a BSP
(fast, no code) and move to a direct build like this once volume justifies
the engineering time. Either fits the reseller plan; this just changes
what you're reselling (your own tech vs. someone else's platform).

## What you need before this runs live

1. **A Meta Developer app** with WhatsApp + Instagram products added
   (developers.facebook.com) — gives you `WHATSAPP_PHONE_NUMBER_ID`,
   `WHATSAPP_ACCESS_TOKEN`, `INSTAGRAM_PAGE_ID`, `INSTAGRAM_ACCESS_TOKEN`.
2. **Business verification with Meta** — required before you can message
   customers who haven't messaged you first, and before high-volume sending.
   This step commonly takes days, not minutes — start it early.
3. **A public HTTPS URL** for the webhook (Meta won't call `localhost`).
   Easiest options: Railway, Render, or a small VPS — deploy this repo,
   then point Meta's webhook config at `https://your-domain/webhook`.
4. **An OpenAI API key** (platform.openai.com) and a **Razorpay account**
   (razorpay.com) for `OPENAI_API_KEY` / `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET`.
5. Fill in **`businessConfig.js`** with Relens' real hours, services, and
   prices — the AI only answers from that file, so accuracy there matters.

## Running it locally

```bash
cp .env.example .env      # fill in your real values, never commit this file
npm install
npm start
```

## Honest limitations of this starter version

- **No database.** Conversation history and orders aren't saved anywhere
  yet — add one (Postgres/SQLite) before relying on this for real bookings.
- **Payment amount is hardcoded** (₹499 placeholder) in `server.js`. Have
  the AI extract the actual service + price, or ask a follow-up question,
  before generating a real payment link.
- **Single business only**, on purpose — `businessConfig.js` is the one
  file you'd copy and edit per client once you're reselling this, so each
  client's instance stays isolated.
- Not yet tested against live Meta/OpenAI/Razorpay traffic — this sandbox
  has no network access, so everything here is syntax-checked but unrun.
  Test carefully with Meta's test numbers before going live with customers.
