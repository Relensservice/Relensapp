// EDIT THIS FILE for Relens — and copy + edit it again for every client
// business you resell this to later. It's the only file that should
// change between businesses; everything else stays the same.

module.exports = {
  businessName: 'Relens',
  bookingLink: 'https://relens.setmore.com/',

  // Fill these in from your real price list / Setmore listing.
  hours: '[e.g. 10:00 AM – 8:00 PM, Mon–Sat]',
  services: [
    { name: '[Service name]', price: '[₹ price]' },
    { name: '[Service name]', price: '[₹ price]' },
  ],

  // The AI only answers from this text — it will not invent details,
  // so keep it accurate and update it whenever your offerings change.
  aboutText: `[2-3 sentences describing the business, what it offers,
  and how it works — e.g. "Relens is a home-visit optical service in
  Puducherry offering eye check-ups, frame fittings, and lens
  replacement at the customer's doorstep."]`,
};
